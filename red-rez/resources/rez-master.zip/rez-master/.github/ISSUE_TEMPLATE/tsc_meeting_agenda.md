---
name: TSC Meeting Agenda
about: Create a TSC Meeting Agenda
title: 'TSC Meeting YYYY-MM-DD'
labels: TSC-Meeting
assignees: ''

---

Please respond to this issue with items you would like to see added to the agenda.

Items from attendees of TSC Meetings are prioritized above others, though ad-hoc reprioritization and discussion will occur.

Current agenda below:

* Category
  * Agenda Item
  * Another Item
* Another Category
  * More Items

