# Rez TSC Meeting Notes - 2022-08-18

Host: TBD

Secretary: TBD

TSC Attendees:
  * [ ] Allan Johns - NVIDIA
  * [ ] Brendan Abel - Walt-Disney Imagineering
  * [ ] Jean-Christophe Morin - Freelance
  * [ ] Stephen Mackenzie - NVIDIA
  * [ ] Thorsten Kaufmann - Mackevision / Accenture

Other Attendees:
  * [ ] TBD

## Agenda:
  * Agenda Issue: [https://github.com/AcademySoftwareFoundation/rez/issues/1362]
  * [X] TBD

## Short Version / Decisions / Action Items / Important Links

* Decisions:
  * [x] TBD
* Action Items:
  * [ ] TBD
* Links:
  * [TBD]

## Details

### Agenda Item
* (TBD) Blah