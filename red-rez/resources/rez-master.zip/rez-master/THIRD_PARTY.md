# Third Party Packages

Rez ships with some embedded packages. For more info, see
[here](src/rez/vendor/README.md)
