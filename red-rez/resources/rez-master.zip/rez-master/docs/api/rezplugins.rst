Rez Plugins
===========

Subpackages
-----------

.. toctree::

    rezplugins.build_system
    rezplugins.release_hook
    rezplugins.release_vcs
    rezplugins.shell
    rezplugins.source_retriever

Module contents
---------------

.. automodule:: rezplugins
    :members:
    :undoc-members:
    :show-inheritance:
