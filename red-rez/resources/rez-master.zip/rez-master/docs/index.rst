REZ API Reference
=================

.. toctree::
    :maxdepth: 2
    :numbered:

    api/modules
    one-liners


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
