Welcome to install your first rez extension!

Currently, please pip install this Python package into Rez's venv, and run
```
$ rez -i
```
You should see a plugin named "world" in the plugin list.
And now you could do
```
$ rez world -h
```
to see what you could do about it.
