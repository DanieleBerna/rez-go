# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


world = {
    "message": "welcome to this world."
}
