

def hello():
    print("Hello world!")
