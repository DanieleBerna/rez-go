
Source within this directory is used to perform build-related tasks, but is not
installed as part of rez.

Note: The embedded virtualenv found in this dir is only used up to python v3.6.
From v3.7 onwards, python's native `venv` module is used instead. See
https://github.com/AcademySoftwareFoundation/rez/releases/tag/2.72.0.
