
Note: This can be removed when python < 3.7 support is dropped. From 3.7
onwards, the rez installation uses python's builtin `venv` module to create
the installation virtualenv.
