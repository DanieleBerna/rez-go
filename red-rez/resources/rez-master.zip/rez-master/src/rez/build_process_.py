# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


import warnings
from rez.build_process import *  # noqa


warnings.warn(
    "rez.build_process_ is deprecated; import rez.build_process instead",
    DeprecationWarning
)
