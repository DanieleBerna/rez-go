#include <iostream>


int main(int argc, char** argv)
{
    std::cout << "Oh hai!" << std::endl;
    return 0;
}
