#ifndef _SUPWORLD_SPANISHGREET__H_
#define _SUPWORLD_SPANISHGREET__H_

#include <string>

namespace supworld {

	std::string spanish_greet();

}

#endif
