name = 'whack'
version = '1'
authors = ["joe.bloggs"]
uuid = "4e9f63cbc4794453b0031f0c5ff50759"
description = "a deliberately broken package"

build_command = "python {root}/build.py {install}"
