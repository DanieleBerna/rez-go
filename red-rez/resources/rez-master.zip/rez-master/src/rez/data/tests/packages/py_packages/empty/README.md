A deliberately empty package family.
