name = 'versioned'
version = '3.0'

def commands():
    env.PATH.append("{root}/bin")
