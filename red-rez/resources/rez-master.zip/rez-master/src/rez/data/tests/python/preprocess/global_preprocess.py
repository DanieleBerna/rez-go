def inject_data(this, data):
    data['added_by_global_preprocess'] = True
