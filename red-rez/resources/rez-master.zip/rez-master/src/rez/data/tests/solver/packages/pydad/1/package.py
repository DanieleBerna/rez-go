name = "pydad"
version = "1"

requires = ["pyson-1"]
