name = "pymum"
version = "1"

requires = ["pydad-1"]
