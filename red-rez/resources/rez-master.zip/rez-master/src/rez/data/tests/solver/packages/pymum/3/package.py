name = "pymum"
version = "3"

requires = ["pydad-3"]
