name = "pyodd"
version = "1"

requires = ["pyfoo"]
