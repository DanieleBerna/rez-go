name = "pyson"
version = "1"

requires = ["pymum-1"]
