name = "pysplit"
version = "6"

requires = ["python-2.6"]
