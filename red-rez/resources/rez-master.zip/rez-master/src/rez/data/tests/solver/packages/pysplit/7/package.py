name = "pysplit"
version = "7"

requires = ["python-2.7"]
