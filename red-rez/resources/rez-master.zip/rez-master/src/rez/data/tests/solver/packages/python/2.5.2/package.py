name = "python"
version = "2.5.2"
