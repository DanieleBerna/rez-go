name = "test_variant_split_mid2"
version = "2.0"

variants = [["test_variant_split_end-1"], ["test_variant_split_end-3"]]
