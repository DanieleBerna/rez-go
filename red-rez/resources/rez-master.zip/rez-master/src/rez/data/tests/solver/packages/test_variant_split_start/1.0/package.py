name = "test_variant_split_start"
version = "1.0"

variants = [["test_variant_split_mid1-1"], ["test_variant_split_mid2-2"]]
