# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


import warnings
from rez.package_maker import *  # noqa


warnings.warn(
    "rez.package_maker__ is deprecated; import rez.package_maker instead",
    DeprecationWarning
)
