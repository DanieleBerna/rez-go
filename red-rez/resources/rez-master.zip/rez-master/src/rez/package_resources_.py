# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


import warnings
from rez.package_resources import *  # noqa


warnings.warn(
    "rez.package_resources_ is deprecated; import rez.package_resources instead",
    DeprecationWarning
)
