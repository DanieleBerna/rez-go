# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


import warnings
from rez.packages import *  # noqa


warnings.warn(
    "rez.packages_ is deprecated; import rez.packages instead",
    DeprecationWarning
)
