# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


"""
unit tests for 'schema' module
"""
import unittest
from rez.vendor.schema.test_schema import TestSchema  # noqa


if __name__ == '__main__':
    unittest.main()
