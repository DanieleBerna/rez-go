# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


# Update this value to version up Rez. Do not place anything else in this file.
_rez_version = "2.111.3"
