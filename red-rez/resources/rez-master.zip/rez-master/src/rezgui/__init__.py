# SPDX-License-Identifier: Apache-2.0
# Copyright Contributors to the Rez Project


organisation_name = "AcademySoftwareFoundation"
application_name = "rez-gui"
