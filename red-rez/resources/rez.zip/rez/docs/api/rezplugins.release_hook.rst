rezplugins.release_hook package
===============================

Submodules
----------

rezplugins.release_hook.emailer module
--------------------------------------

.. automodule:: rezplugins.release_hook.emailer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rezplugins.release_hook
    :members:
    :undoc-members:
    :show-inheritance:
