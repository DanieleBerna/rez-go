import warnings
from rez.build_process import *


warnings.warn(
    "rez.build_process_ is deprecated; import rez.build_process instead",
    DeprecationWarning
)
