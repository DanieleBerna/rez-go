import warnings
from rez.package_maker import *


warnings.warn(
    "rez.package_maker__ is deprecated; import rez.package_maker instead",
    DeprecationWarning
)
