#ifndef _SUPWORLD_GHETTOGREET__H_
#define _SUPWORLD_GHETTOGREET__H_

#include <string>

namespace supworld {

	std::string ghetto_greet();

}

#endif
