
def get_authors():
    return [
        "tweedle-dee",
        "tweedle-dum"
    ]
