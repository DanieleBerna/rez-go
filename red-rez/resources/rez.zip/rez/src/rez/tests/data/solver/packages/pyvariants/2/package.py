name = "pyvariants"
version = "2"

variants = [["python-2.7.0"], ["python-2.6.8", "nada"]]