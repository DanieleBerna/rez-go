name = "test_variant_split_end"
version = "2.0"

variants = [["!test_variant_split_start"], ["!test_variant_split_mid1"]]
