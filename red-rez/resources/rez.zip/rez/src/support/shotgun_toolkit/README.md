# Shotgun Integration hooks

...but where did it all go?

After `nerdvegas/rez` issues [822] and PR [823], the Shotgun hooks have
been moved to https://github.com/nerdvegas/rez-shotgun


[822]: https://github.com/nerdvegas/rez/issues/822
[823]: https://github.com/nerdvegas/rez/pull/823
