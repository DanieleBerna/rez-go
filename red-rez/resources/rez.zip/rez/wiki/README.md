# rez-wiki

This directory holds the content used to produce the Rez Wiki documentation
found [here](https://github.com/nerdvegas/rez/wiki).

You should include relevant wiki updates with your code PRs.

To update the wiki, make your changes here, then run ./update-wiki.sh. The
current repository status is irrelevant - you don't have to have anything
committed nor pushed in order to update the wiki repository.
