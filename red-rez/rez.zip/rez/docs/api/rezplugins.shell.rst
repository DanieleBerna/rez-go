rezplugins.shell package
========================

Submodules
----------

rezplugins.shell.bash module
----------------------------

.. automodule:: rezplugins.shell.bash
    :members:
    :undoc-members:
    :show-inheritance:

rezplugins.shell.csh module
---------------------------

.. automodule:: rezplugins.shell.csh
    :members:
    :undoc-members:
    :show-inheritance:

rezplugins.shell.sh module
--------------------------

.. automodule:: rezplugins.shell.sh
    :members:
    :undoc-members:
    :show-inheritance:

rezplugins.shell.tcsh module
----------------------------

.. automodule:: rezplugins.shell.tcsh
    :members:
    :undoc-members:
    :show-inheritance:

rezplugins.shell.windows module
-------------------------------

.. automodule:: rezplugins.shell.windows
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rezplugins.shell
    :members:
    :undoc-members:
    :show-inheritance:
