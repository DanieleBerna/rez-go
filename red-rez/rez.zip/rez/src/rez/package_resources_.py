import warnings
from rez.package_resources import *


warnings.warn(
    "rez.package_resources_ is deprecated; import rez.package_resources instead",
    DeprecationWarning
)
