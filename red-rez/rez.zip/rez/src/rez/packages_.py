import warnings
from rez.packages import *


warnings.warn(
    "rez.packages_ is deprecated; import rez.packages instead",
    DeprecationWarning
)
