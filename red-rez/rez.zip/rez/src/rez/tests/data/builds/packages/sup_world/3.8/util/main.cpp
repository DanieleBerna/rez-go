#include <iostream>
#include "ghetto_greet.h"

using namespace supworld;


int main(int argc, char** argv)
{
	std::cout << ghetto_greet() << std::endl;
	return 0;
}
