import shutil
import os.path


def build(source_path, build_path, install_path, targets):
    pass
