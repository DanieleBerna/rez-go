name = "test_variant_split_mid2"
version = "1.0"

variants = [["test_variant_split_end-3"], ["test_variant_split_end-1"]]
