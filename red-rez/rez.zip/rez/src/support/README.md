
Source within this directory is not installed as part of rez; it is here to provide
supporting code for integration with third party applications.
